fd_lib

Current version: 0.3
This is my personal Pure Data library of abstractions and externals.
Get Pure Data here: https://msp.ucsd.edu
It has:
    288 abstractions,
    37 externals,
    shell scripts, and more.
For an overview of the library, go open '_overview.pd'
For instructions on how to compile see INSTALL.txt.

fd_lib is now available via `deken`, Pd's package manager.
Open Pure Data and go to `Help > Find Externals`,
then type `fd_lib` and download the binaries.

Use at your own risk and have fun!
fdch
